#!/usr/bin/env python3
# Diagnostic-only function counter. Performance measurements use unwrapped casts.
import json
from compare import ROOT,PREFIX,psql,queries,values
psql(PREFIX+'''CREATE OR REPLACE FUNCTION summary_probe_jsonb(value text) RETURNS jsonb LANGUAGE plpgsql IMMUTABLE STRICT COST 1 AS $$ BEGIN RETURN value::jsonb; END $$;''')
records={}
for name,sql in queries('load-user-00',cast='summary_probe_jsonb(document)').items():
    output=values(psql(PREFIX+"SET track_functions='all'; BEGIN; EXPLAIN (ANALYZE, BUFFERS, VERBOSE, FORMAT JSON) "+sql+"; SELECT json_build_object('calls',calls,'total_time',total_time) FROM pg_stat_xact_user_functions WHERE funcid='summary_probe_jsonb(text)'::regprocedure; ROLLBACK;"))
    assert len(output)==2,(name,output)
    plan,stats=output
    records[name]={'calls':stats['calls'],'rows':plan[0]['Plan']['Actual Rows'],'plan':plan}
(ROOT/'probe.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({name:{'calls':r['calls'],'rows':r['rows']} for name,r in records.items()},indent=2))
