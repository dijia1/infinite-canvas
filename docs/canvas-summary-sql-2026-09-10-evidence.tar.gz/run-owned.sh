#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
: "${LOADTEST_BINARY:?Build ./cmd/loadtest and set LOADTEST_BINARY first}"
test -x "$LOADTEST_BINARY"
if [[ -f "$root/manifest.json" ]]; then echo "Use a fresh extraction directory" >&2; exit 1; fi
container_name="infinite-canvas-summary-sql-$(date +%s)-$$"
api_pid=""
cleanup() {
  if [[ -n "$api_pid" ]]; then kill -TERM "$api_pid" 2>/dev/null || true; wait "$api_pid" || true; fi
  docker logs "$container_name" > "$root/postgres.log" 2>&1 || true
  docker rm -f -v "$container_name" >/dev/null 2>&1 || true
}
trap cleanup EXIT
trap 'exit 130' INT TERM
printf '%s' "$container_name" > "$root/container-name"
test_password="$(openssl rand -hex 16)"
docker run --detach --name "$container_name" --cpus=2 --memory=1g --publish 127.0.0.1::5432 -e POSTGRES_DB=infinite_canvas_test -e POSTGRES_USER=loadtest -e "POSTGRES_PASSWORD=$test_password" postgres:17-alpine -c shared_preload_libraries=pg_stat_statements -c track_io_timing=on > "$root/container-id"
for attempt in $(seq 1 60); do
  if docker exec "$container_name" pg_isready -U loadtest -d infinite_canvas_test >/dev/null 2>&1; then break; fi
  sleep 1
done
docker exec "$container_name" psql -U loadtest -d infinite_canvas_test -c 'CREATE EXTENSION pg_stat_statements;'
db_port="$(docker port "$container_name" 5432 | awk -F: '{print $NF}')"
export TEST_DATABASE_DSN="postgres://loadtest:$test_password@127.0.0.1:$db_port/infinite_canvas_test?sslmode=disable"
mkdir -p "$root/server"
GOMAXPROCS=4 "$LOADTEST_BINARY" -mode server -manifest "$root/manifest.json" -out "$root/server" > "$root/server-start.log" 2>&1 &
api_pid=$!
for attempt in $(seq 1 120); do
  [[ -f "$root/manifest.json" ]] && break
  kill -0 "$api_pid" 2>/dev/null || { cat "$root/server-start.log"; exit 1; }
  sleep 1
done
test -f "$root/manifest.json"
printf 'Owned SQL comparison database seeded and ready.\n'
wait "$api_pid"
