SELECT
    c.id, c.title, c.revision, c.created_at, c.updated_at,
    CASE WHEN jsonb_typeof(p.doc -> 'nodes') = 'array'
         THEN jsonb_array_length(p.doc -> 'nodes') ELSE 0 END AS node_count,
    CASE WHEN jsonb_typeof(p.doc -> 'connections') = 'array'
         THEN jsonb_array_length(p.doc -> 'connections') ELSE 0 END AS connection_count
FROM canvas_projects AS c
CROSS JOIN LATERAL (
    SELECT c.document::jsonb AS doc
    OFFSET 0 -- 保持独立求值，避免子查询展开后重复转换。
) AS p
WHERE c.owner_uid = $1
ORDER BY c.updated_at DESC;
