#!/usr/bin/env python3
"""SQL-only comparison against an owned local loadtest PostgreSQL container."""
import json, math, random, re, statistics, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CONTAINER=(ROOT/'container-name').read_text().strip()
assert re.fullmatch(r'infinite-canvas-summary-sql-[0-9]+-[0-9]+', CONTAINER)
def psql(sql):
    return subprocess.check_output(['docker','exec','-i',CONTAINER,'psql','-X','-qAt','-v','ON_ERROR_STOP=1','-U','loadtest','-d','infinite_canvas_test'],input=sql,text=True)
SCHEMA=psql("SELECT nspname FROM pg_namespace WHERE nspname LIKE 'loadtest_%';").strip()
assert re.fullmatch(r'loadtest_[a-z0-9_]+',SCHEMA)
PREFIX=f'SET search_path TO "{SCHEMA}",public; SET statement_timeout=\'20s\'; '
def values(raw):
    decoder=json.JSONDecoder(); result=[]
    while raw.strip():
        raw=raw.lstrip(); value,end=decoder.raw_decode(raw); result.append(value);raw=raw[end:]
    return result
metadata='id, title, revision, created_at, updated_at'
def counts(d):
    return f"CASE WHEN jsonb_typeof({d} -> 'nodes') = 'array' THEN jsonb_array_length({d} -> 'nodes') ELSE 0 END AS node_count, CASE WHEN jsonb_typeof({d} -> 'connections') = 'array' THEN jsonb_array_length({d} -> 'connections') ELSE 0 END AS connection_count"
def queries(owner,cast='document::jsonb',table='canvas_projects'):
    # owner strings are controlled fixture IDs, not external input.
    assert re.fullmatch(r'[a-z0-9-]+',owner)
    where=f"WHERE owner_uid = '{owner}'"
    inner=f'SELECT {metadata}, {cast} AS doc FROM {table} {where}'
    return {
      'current':f'SELECT {metadata}, {counts("("+cast+")")} FROM {table} {where} ORDER BY updated_at DESC',
      'subquery_inline':f'SELECT {metadata}, {counts("doc")} FROM ({inner}) p ORDER BY updated_at DESC',
      'lateral_inline':f'SELECT {metadata}, {counts("p.doc")} FROM {table} CROSS JOIN LATERAL (SELECT {cast} AS doc) p {where} ORDER BY updated_at DESC',
      'cte_materialized':f'WITH parsed AS MATERIALIZED ({inner}) SELECT {metadata}, {counts("doc")} FROM parsed ORDER BY updated_at DESC',
      'lateral_offset0':f'SELECT {metadata}, {counts("p.doc")} FROM {table} CROSS JOIN LATERAL (SELECT {cast} AS doc OFFSET 0) p {where} ORDER BY updated_at DESC',
    }
if __name__=='__main__':
    psql(PREFIX+'ANALYZE canvas_projects;')
    details=values(psql(PREFIX+"SELECT json_build_object('server',version(),'document_type',(SELECT data_type FROM information_schema.columns WHERE table_schema=current_schema() AND table_name='canvas_projects' AND column_name='document'),'rows',(SELECT count(*) FROM canvas_projects),'owners',(SELECT count(DISTINCT owner_uid) FROM canvas_projects),'document_bytes',(SELECT sum(octet_length(document)) FROM canvas_projects),'settings',(SELECT json_object_agg(name,setting) FROM pg_settings WHERE name IN ('jit','work_mem','shared_buffers','max_parallel_workers_per_gather','server_version')),'indexes',(SELECT json_agg(indexdef) FROM pg_indexes WHERE schemaname=current_schema() AND tablename='canvas_projects'));"))[0]
    (ROOT/'environment.json').write_text(json.dumps(details,indent=2)+'\n')
    q=queries('load-user-00')
    (ROOT/'queries.json').write_text(json.dumps(q,indent=2)+'\n')
    raw=psql(PREFIX+''.join('EXPLAIN (ANALYZE, BUFFERS, VERBOSE, FORMAT JSON) '+sql+';\n' for sql in q.values()))
    for name,plan in zip(q,values(raw)):
        (ROOT/(name+'-plan.json')).write_text(json.dumps(plan,indent=2)+'\n')
    # All real fixture users return exactly the same summary fields and counts.
    equality=[]
    for i in range(50):
        uid=f'load-user-{i:02d}'
        result=values(psql(PREFIX+'\n'.join("SELECT jsonb_agg(to_jsonb(t) ORDER BY id) FROM ("+sql+") t;" for sql in queries(uid).values())))
        assert len(result)==5 and all(x==result[0] for x in result), uid
        equality.append({'owner':uid,'rows':len(result[0]),'equal':True})
    (ROOT/'equality.json').write_text(json.dumps(equality,indent=2)+'\n')
    # Warm cache, shuffled paired rounds. Execution Time excludes client/Docker startup.
    rng=random.Random(1000); schedule=[]; statements=[]
    for round_no in range(64):
        uid=f'load-user-{round_no%50:02d}'
        variants=list(queries(uid).items());rng.shuffle(variants)
        for name,sql in variants:
            schedule.append({'round':round_no,'owner':uid,'variant':name,'warmup':round_no<4})
            statements.append('EXPLAIN (ANALYZE, BUFFERS, TIMING OFF, FORMAT JSON) '+sql+';')
    plans=values(psql(PREFIX+'\n'.join(statements)))
    assert len(plans)==len(schedule)
    samples=[]
    for point,plan in zip(schedule,plans):
        p=plan[0]; point.update({'execution_ms':p['Execution Time'],'planning_ms':p['Planning Time'],'shared_hit':p['Plan']['Shared Hit Blocks'],'shared_read':p['Plan']['Shared Read Blocks'],'temp_read':p['Plan']['Temp Read Blocks'],'temp_written':p['Plan']['Temp Written Blocks']});samples.append(point)
    (ROOT/'samples.json').write_text(json.dumps(samples,indent=2)+'\n')
    summary={}
    for name in q:
        ss=[s for s in samples if s['variant']==name and not s['warmup']];times=sorted(s['execution_ms'] for s in ss)
        summary[name]={'queries':len(times),'mean_ms':statistics.mean(times),'p50_ms':times[math.ceil(.5*len(times))-1],'p95_ms':times[math.ceil(.95*len(times))-1],'p99_ms':times[math.ceil(.99*len(times))-1],'min_ms':min(times),'max_ms':max(times),'shared_hit_mean':statistics.mean(s['shared_hit'] for s in ss),'shared_read_total':sum(s['shared_read'] for s in ss),'temp_blocks_total':sum(s['temp_read']+s['temp_written'] for s in ss)}
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({'environment':details,'summary':summary},indent=2))
