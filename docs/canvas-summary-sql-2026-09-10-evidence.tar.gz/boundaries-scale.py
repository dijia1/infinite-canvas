#!/usr/bin/env python3
import json,math,random,statistics,subprocess
from compare import ROOT,PREFIX,psql,queries,values
# Dedicated diagnostic rows, in the disposable database only.
psql(PREFIX+'''
INSERT INTO canvas_projects (id,owner_uid,title,revision,created_at,updated_at,document)
SELECT 'edge-'||n,'summary-edge','edge',1,n::text,n::text,doc
FROM (VALUES (1,NULL::text),(2,'null'),(3,'{}'),(4,'{"nodes":null,"connections":null}'),(5,'{"nodes":{},"connections":"x"}'),(6,'{"nodes":[],"connections":[]}'),(7,'{"nodes":[1,2],"connections":[{}]}'),(8,'[]'),(9,'"string"'),(10,'{"nodes":[{}],"connections":42}')) t(n,doc);
INSERT INTO canvas_projects (id,owner_uid,title,revision,created_at,updated_at,document)
VALUES ('bad-json','summary-bad','invalid',1,'0','0','not json');
''')
result=values(psql(PREFIX+'\n'.join('SELECT jsonb_agg(to_jsonb(t) ORDER BY id) FROM ('+sql+') t;' for sql in queries('summary-edge').values())))
assert len(result)==5 and all(x==result[0] for x in result)
assert [(r['node_count'],r['connection_count']) for r in sorted(result[0],key=lambda r:int(r['id'].split('-')[1]))]==[(0,0),(0,0),(0,0),(0,0),(0,0),(0,0),(2,1),(0,0),(0,0),(1,0)]
bad=[]
for name,sql in queries('summary-bad').items():
 try: psql(PREFIX+'\\set VERBOSITY sqlstate\n'+sql+';');raise AssertionError('invalid JSON accepted')
 except subprocess.CalledProcessError as e: bad.append({'variant':name,'rejected':True})
(ROOT/'boundaries.json').write_text(json.dumps({'valid_equivalent':True,'valid_rows':result[0],'invalid_json_rejected':bad,'foreign_invalid_document_did_not_break_valid_owner':True},indent=2)+'\n')
for n in [30,300]:
 owner=f'summary-scale-{n}'
 psql(PREFIX+f'''INSERT INTO canvas_projects (id,owner_uid,title,revision,created_at,updated_at,document)
 SELECT '{owner}-'||i||'-'||c.id,'{owner}',c.title,c.revision,c.created_at,lpad(i::text,4,'0')||c.updated_at,
 jsonb_set(c.document::jsonb,'{{viewport,x}}',to_jsonb(i))::text
 FROM canvas_projects c CROSS JOIN generate_series(1,{n//3}) i WHERE c.owner_uid='load-user-00';''')
psql(PREFIX+'ANALYZE canvas_projects;')
rng=random.Random(1000); output={};
for n in [30,300]:
 owner=f'summary-scale-{n}'; q={k:v for k,v in queries(owner).items() if k in ['current','cte_materialized','lateral_offset0']}
 equivalent=values(psql(PREFIX+'\n'.join('SELECT md5(jsonb_agg(to_jsonb(t) ORDER BY id)::text) AS digest FROM ('+sql+') t;' for sql in q.values()).replace('SELECT md5(', 'SELECT to_json(md5(').replace(') AS digest', ')) AS digest')))
 assert len(equivalent)==3 and len(set(equivalent))==1
 plans=values(psql(PREFIX+'\n'.join('EXPLAIN (ANALYZE,BUFFERS,VERBOSE,FORMAT JSON) '+sql+';' for sql in q.values())))
 for name,plan in zip(q,plans): (ROOT/(f'scale-{n}-'+name+'-plan.json')).write_text(json.dumps(plan,indent=2)+'\n')
 schedule=[]; statements=[]
 for round_no in range(14):
  variants=list(q.items());rng.shuffle(variants)
  for name,sql in variants:
   schedule.append({'round':round_no,'variant':name,'warmup':round_no<2})
   statements.append('EXPLAIN (ANALYZE,BUFFERS,TIMING OFF,FORMAT JSON) '+sql+';')
 plans=values(psql(PREFIX+'\n'.join(statements)))
 samples=[]
 for s,plan in zip(schedule,plans):
  d=plan[0];p=d['Plan'];s.update({'execution_ms':d['Execution Time'],'shared_hit':p['Shared Hit Blocks'],'shared_read':p['Shared Read Blocks'],'temp_read':p['Temp Read Blocks'],'temp_written':p['Temp Written Blocks']});samples.append(s)
 summary={}
 for name in q:
  ss=[s for s in samples if s['variant']==name and not s['warmup']];ts=sorted(s['execution_ms'] for s in ss)
  summary[name]={'queries':len(ts),'mean_ms':statistics.mean(ts),'p50_ms':ts[math.ceil(.5*len(ts))-1],'p95_ms':ts[math.ceil(.95*len(ts))-1],'shared_hit_mean':statistics.mean(s['shared_hit'] for s in ss),'temp_read_mean':statistics.mean(s['temp_read'] for s in ss),'temp_written_mean':statistics.mean(s['temp_written'] for s in ss)}
 output[str(n)]={'equivalent':True,'summary':summary,'samples':samples}
(ROOT/'scale.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({n:o['summary'] for n,o in output.items()},indent=2))
