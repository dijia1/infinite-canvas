import csv, json
from pathlib import Path
root = Path(__file__).parent
out = {}
for label in ("before", "after"):
    run = root / label
    summary = json.loads((run / "summary.json").read_text())["50"]
    statements = list(csv.DictReader((run / "pg-statements.csv").open()))
    queries = [r for r in statements if 'from "canvas_projects"' in r["query"].lower() and "order by updated_at desc" in r["query"].lower()]
    assert len(queries) == 1, queries
    list_api = summary["api_steady"]["Canvas list"]
    out[label] = {
        "stage": summary["stage"], "steady": summary["steady"],
        "api_steady": summary["api_steady"], "workload_all_phases": summary["workload_all_phases"],
        "server": summary["server"], "business_and_conflict": summary["business_and_conflict"],
        "checks": summary["checks"], "consistency": json.loads((run/"consistency.json").read_text()),
        "list_sql": queries[0], "list_mean_response_bytes": list_api["response_bytes"] / list_api["requests"],
        "list_byte_share_percent": 100 * list_api["response_bytes"] / summary["steady"]["response_bytes"],
        "binary_sha256": (run/"binary-sha256.txt").read_text().split()[0],
    }
    for phase in ("before", "after"):
        out[label]["database_" + phase] = json.loads((run/("database-"+phase+".json")).read_text())
(root/"results.json").write_text(json.dumps(out, indent=2, ensure_ascii=False) + "\n")
for label, d in out.items():
    print(label, json.dumps({"list":d["api_steady"]["Canvas list"], "bytes_per_list":d["list_mean_response_bytes"], "list_share":d["list_byte_share_percent"], "steady_bytes":d["steady"]["response_bytes"], "sql":d["list_sql"], "server":d["server"], "checks":d["checks"]}, ensure_ascii=False))
